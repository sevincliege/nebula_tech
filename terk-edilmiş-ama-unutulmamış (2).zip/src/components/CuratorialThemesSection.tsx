import React, { useState } from 'react';
import { TRANSLATIONS, type Language, type CuratorialThemeItem } from '../data/translations';

interface CuratorialThemesSectionProps {
  lang: Language;
}

export const CuratorialThemesSection: React.FC<CuratorialThemesSectionProps> = ({ lang }) => {
  const t = TRANSLATIONS[lang].themesSection;
  const [activeThemeId, setActiveThemeId] = useState<CuratorialThemeItem['id']>('weathering');

  const activeTheme =
    t.items.find((item) => item.id === activeThemeId) ?? t.items[0];

  return (
    <section id="miras" className="py-20 border-b border-white/10 bg-[#0B0E13]">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Editorial Header & Theme Selector */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div>
            <p className="text-xs font-mono uppercase tracking-widest text-[#E28A47] mb-3">
              {t.kicker}
            </p>
            <h2 className="font-serif text-3xl md:text-4xl font-medium text-[#F3F0E8]">
              {t.title}
            </h2>
            <p className="text-sm md:text-base text-[#B5B0A6] mt-2.5 max-w-2xl leading-relaxed">
              {t.desc}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-1 p-1 bg-[#12161E] border border-white/10 rounded-lg self-start">
            {t.items.map((item) => {
              const isActive = item.id === activeTheme.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveThemeId(item.id)}
                  className={`px-3.5 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-[#D97736] text-[#090B0E]'
                      : 'text-[#B5B0A6] hover:text-[#F3F0E8]'
                  }`}
                >
                  {item.tabLabel}
                </button>
              );
            })}
          </div>
        </div>

        {/* Two-Column Editorial Exposition + Comparative Table */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          {/* Left: Thematic Essay */}
          <div className="lg:col-span-7 border border-white/10 bg-[#12161E] rounded-lg p-7 md:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-5">
              <p className="text-xs font-mono uppercase tracking-widest text-[#E28A47]">
                {activeTheme.kicker}
              </p>
              <h3 className="font-serif text-2xl md:text-3xl font-medium text-[#F3F0E8] leading-snug">
                {activeTheme.title}
              </h3>
              <p className="font-serif italic text-lg text-[#D6D1C7] leading-relaxed">
                {activeTheme.lead}
              </p>

              <div className="pt-4 border-t border-white/10 space-y-4">
                {activeTheme.paragraphs.map((paragraph, idx) => (
                  <p key={idx} className="text-sm md:text-base text-[#C7C2B8] leading-[1.8]">
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>

            <div className="pt-5 border-t border-white/10">
              <p className="text-xs font-mono uppercase tracking-widest text-[#9B978E] mb-2">
                {t.takeawayLabel}
              </p>
              <p className="text-sm text-[#F3F0E8] leading-relaxed">
                {activeTheme.keyTakeaway}
              </p>
            </div>
          </div>

          {/* Right: Structured Field Comparisons */}
          <div className="lg:col-span-5 border border-white/10 bg-[#12161E] rounded-lg p-7 md:p-8 flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-mono uppercase tracking-widest text-[#9B978E] pb-4 border-b border-white/10">
                {activeTheme.comparisonTitle}
              </h4>

              <div className="divide-y divide-white/10 mt-2">
                {activeTheme.comparisons.map((entry, idx) => (
                  <div key={idx} className="py-5 space-y-1.5">
                    <div className="flex items-baseline justify-between gap-4">
                      <span className="font-serif text-lg font-medium text-[#F3F0E8]">
                        {entry.subject}
                      </span>
                      <span className="text-xs font-mono tabular-nums text-[#E28A47]">
                        0{idx + 1}
                      </span>
                    </div>
                    <p className="text-sm text-[#B5B0A6] leading-relaxed">
                      {entry.detail}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Clean Typographic Index Footer */}
            <div className="pt-6 mt-6 border-t border-white/10 flex items-center justify-between text-xs font-mono text-[#9B978E]">
              <span>0{t.items.findIndex((i) => i.id === activeTheme.id) + 1} / 03</span>
              <span>{lang === 'tr' ? 'KARŞILAŞTIRMALI ARŞİV NOTU' : 'COMPARATIVE ARCHIVE NOTE'}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
