import type { Artifact } from './artifacts';
import type { Language } from './translations';

type ArtifactEnglishOverlay = Pick<
  Artifact,
  | 'name'
  | 'subtitle'
  | 'bodyLabel'
  | 'crewOrTeam'
  | 'abandonedDate'
  | 'distanceLabel'
  | 'dimensions'
  | 'statusNote'
  | 'photoCaption'
  | 'storyOpening'
  | 'storyContinuation'
  | 'storyLegacy'
  | 'pullQuote'
  | 'pullQuoteAttribution'
  | 'finalTransmission'
  | 'environment'
  | 'orbitalObservation'
  | 'scientificBreakthroughs'
  | 'leftBehindItems'
  | 'xraySummary'
  | 'weatheringStages'
> & {
  hotspots: Record<string, { title: string; partCode: string; spec: string; story: string }>;
};

const ARTIFACTS_EN: Record<string, ArtifactEnglishOverlay> = {
  'apollo-11-eagle': {
    name: 'Eagle Descent Stage (LM-5)',
    subtitle: 'The gold-winged launchpad left standing in the Sea of Tranquility',
    bodyLabel: 'Moon',
    crewOrTeam: 'Neil Armstrong, Buzz Aldrin, Michael Collins',
    abandonedDate: 'July 21, 1969 · 17:54 UTC',
    distanceLabel: '384,400 km',
    dimensions: '4.22 m height · 9.45 m footpad span',
    statusNote: 'Nearby LRRR laser retroreflector still returns distance pulses to Earth',
    photoCaption:
      'Fig. 1 — Captured by Buzz Aldrin, showing the Eagle descent stage standing silently beside the deployed flag and scientific experiments on Mare Tranquillitatis.',
    storyOpening:
      'On the afternoon of July 21, 1969, as Neil Armstrong and Buzz Aldrin ignited the ascent engine to climb back toward lunar orbit, the lower half of Eagle stayed anchored in the gray regolith forever. Every gram mattered for the climb off the Moon—so the crew tossed out their lunar overshoes, life-support backpacks, a television camera, and a Hasselblad body before sealing the hatch.',
    storyContinuation:
      'Today, on a windless plain untouched by rain or erosion, Eagle’s four spider-like legs remain locked at the exact angle they settled into in 1969. Only the brutal 300-degree swing between scorching lunar noon and minus 170-degree night slowly embrittles its crinkled golden Kapton blankets. Yet on the forward strut, the stainless-steel plaque still reads without a speck of rust: “We came in peace for all mankind.”',
    storyLegacy:
      'Just meters away sits the 100-prism LRRR laser retroreflector, which has bounced laser beams back to Earth observatories for 57 uninterrupted years—allowing scientists to measure the Moon drifting away from Earth at 3.8 centimeters per year. Today Eagle stands as the anchor monument of the historic Tranquility Base preservation zone.',
    pullQuote:
      '“The Eagle had landed—and at liftoff, it entrusted its own golden cradle to the Sea of Tranquility forever.”',
    pullQuoteAttribution: 'Apollo 11 Mission Logs, July 1969',
    finalTransmission: {
      timestamp: '21 JUL 1969 · 17:54:00 UTC',
      message: '“9, 8, 7, 6, 5, abort stage... Ignition! Very smooth. Very quiet ride.”',
      context:
        'Buzz Aldrin’s call to Houston as the ascent stage separated, leaving the lower stage in eternal silence.',
    },
    environment: {
      tempRange: '-173 °C / +127 °C',
      gravity: '1.62 m/s² (0.165 g)',
      signalDelay: '1.28 seconds',
      hazard: 'Micrometeoroid pitting and unfiltered solar ultraviolet radiation',
    },
    orbitalObservation:
      'Lunar Reconnaissance Orbiter (LRO) passes in 2012 and 2021 resolved Eagle’s octagonal shadow, the scientific experiment track, and astronaut bootpaths at 25 cm per pixel.',
    scientificBreakthroughs: [
      'LRRR laser ranging continues to test general relativity and Earth-Moon orbital drift half a century later.',
      '21.55 kg of lunar basalt confirmed the Moon condensed from a giant ancient Earth impact 4.5 billion years ago.',
      'The passive seismometer revealed “moonquakes” ring for minutes inside a dry, rigid lunar crust.',
    ],
    leftBehindItems: [
      {
        name: 'Goodwill Silicon Disc',
        detail:
          'A coin-sized silicon disc etched microscopically with goodwill messages from leaders of 73 nations.',
      },
      {
        name: 'Gold Olive Branch Pin',
        detail:
          'A 14-karat miniature golden olive branch placed quietly in the dust as an emblem of peace.',
      },
      {
        name: 'Apollo 1 & Cosmonaut Memorials',
        detail:
          'Mission patches and Soviet medallions honoring Gus Grissom, Ed White, Roger Chaffee, Yuri Gagarin, and Vladimir Komarov.',
      },
    ],
    xraySummary:
      'Beneath the crinkled golden Kapton thermal blankets sit four spherical Aerozine-50 and nitrogen tetroxide propellant tanks, the landing radar dish, and depleted oxygen reservoirs sealed inside an octagonal aluminum frame.',
    weatheringStages: {
      early:
        '1969: Ascent exhaust swept away loose surface dust; Mylar foils gleamed bright metallic gold.',
      mid: '1998: Tens of thousands of thermal shock cycles embrittled adhesive seams and pitted foil surfaces.',
      present:
        '2026: Solar wind and cosmic rays have bleached painted markings, yet the descent frame stands nearly intact.',
    },
    hotspots: {
      kapton: {
        title: 'Gold Kapton Thermal Shield',
        partCode: 'Multi-Layer Insulation (MLI)',
        spec: '25-layer aluminized Mylar & Kapton film',
        story:
          'Engineered to shield delicate propellant tanks across a 300 °C temperature swing, these wrinkled golden sheets still preserve the exact creases from liftoff.',
      },
      plaque: {
        title: 'Lunar Commemorative Plaque',
        partCode: 'Stainless Steel · Forward Strut',
        spec: '22.8 × 19.4 cm · Acid-etched engraving',
        story:
          'Bolted to the fourth rung of the ladder, bearing hemispheres of Earth and the signatures of Armstrong, Aldrin, Collins, and President Nixon.',
      },
      engine: {
        title: 'DPS Descent Engine Bell',
        partCode: 'TRW LMDE-10 · Throttleable Engine',
        spec: '45.04 kN max thrust · Columbium alloy',
        story:
          'The first throttleable rocket nozzle to carry humans to a soft landing on another world—later serving as the launchpad for the ascent cabin.',
      },
      mesa: {
        title: 'Discarded Life-Support Packs & Gear',
        partCode: 'Weight-Saving Jettison Inventory',
        spec: '≈ 102 kg left beside the footpad (PLSS, boots, camera)',
        story:
          'To ensure enough fuel margin for lunar orbit rendezvous, dust-caked boots and precision cameras were tossed out onto the regolith.',
      },
    },
  },
  'apollo-15-lrv': {
    name: 'Lunar Roving Vehicle LRV-1',
    subtitle: 'The first electric car parked along the rim of Hadley Rille',
    bodyLabel: 'Moon',
    crewOrTeam: 'David Scott, James Irwin, Alfred Worden',
    abandonedDate: 'August 2, 1971 · 17:11 UTC',
    distanceLabel: '384,400 km',
    dimensions: '3.10 m length · 2.06 m width',
    statusNote: 'Tire tracks remain clearly visible in Lunar Reconnaissance Orbiter imagery',
    photoCaption:
      'Fig. 2 — After driving 27.9 km across lunar craters, David Scott and James Irwin parked LRV-1 east of the Falcon lander before liftoff.',
    storyOpening:
      'Apollo 15 astronauts David Scott and James Irwin were the first humans to drive an automobile off Earth. Over three days beside the winding canyon of Hadley Rille, they reached 13 km/h and covered 27.9 kilometers. When departure arrived, they parked the rover roughly 90 meters from the Falcon lander, angling its front wheels toward the canyon.',
    storyContinuation:
      'That parking spot was chosen with care: the remote-controlled television camera mounted on the rover’s bow was aimed back at Falcon so flight controllers in Houston could pan and tilt it to broadcast humanity’s liftoff live. After the ascent flame vanished, the camera stared at the empty lander legs for a few hours until its silver-zinc batteries faded. Fifty-five years later, LRV-1 still waits in its own tire tracks.',
    storyLegacy:
      'LRV-1 enabled the crew to reach the foot of the Apennine Mountains and recover the 4.1-billion-year-old “Genesis Rock,” revealing the Moon’s primordial magma-ocean crust. Beside this rover, David Scott also dropped a falcon feather and a geological hammer together in airless vacuum—confirming Galileo’s law of gravity live on television.',
    pullQuote:
      '“Humanity parked an electric car beside an alien canyon and went home without taking the keys.”',
    pullQuoteAttribution: 'Cosmic Archaeology Curatorial Note',
    finalTransmission: {
      timestamp: '02 AUG 1971 · 19:25:10 UTC',
      message:
        '“Camera tilt locked. Falcon ascent tracked; battery bus dropping below operational threshold.”',
      context:
        'Controlled remotely from Houston by Ed Fendell, the rover’s TV camera transmitted until its batteries expired.',
    },
    environment: {
      tempRange: '-165 °C / +120 °C',
      gravity: '1.62 m/s² (0.165 g)',
      signalDelay: '1.28 seconds',
      hazard: 'Electrostatically charged abrasive lunar dust clinging to hinges',
    },
    orbitalObservation:
      'Low-altitude LRO orbital passes clearly capture the Falcon descent stage, LRV-1’s bright chassis, and winding twin tire tracks along the Hadley Rille rim.',
    scientificBreakthroughs: [
      'Discovery of the 4.1-billion-year-old Genesis Rock anorthosite unlocked the history of the lunar highland crust.',
      'Close-up inspection of layered basalt outcrops exposed inside the Hadley Rille canyon walls.',
      'Live vacuum verification of Galileo’s equal-acceleration free-fall experiment.',
    ],
    leftBehindItems: [
      {
        name: 'Fallen Astronaut Sculpture',
        detail:
          'An 8.5 cm aluminum figurine by Belgian artist Paul Van Hoeydonck placed beside a plaque naming 14 fallen astronauts and cosmonauts.',
      },
      {
        name: 'Falcon Feather & Pocket Bible',
        detail:
          'The feather from Scott’s famous gravity drop and a small pocket Bible James Irwin left resting on the rover console.',
      },
      {
        name: 'Remote RCA Color TV Unit',
        detail:
          'Steered via joystick from Houston, its gold lens still points directly toward the empty Falcon pad.',
      },
    ],
    xraySummary:
      'Inside the folding aluminum chassis sit two 36-volt silver-zinc potassium hydroxide batteries and four independent 0.25-horsepower traction motors housed inside the wheel hubs.',
    weatheringStages: {
      early:
        '1971: Fine gray lunar dust coated the orange fenders while the umbrella dish pointed accurately at Earth.',
      mid: '1999: Nylon seat straps and polymer wire insulation gradually yellowed and cracked under raw solar UV.',
      present:
        '2026: Extreme day-night thermal cycling has stressed rivets, yet the wire-mesh wheels still support the chassis.',
    },
    hotspots: {
      dish: {
        title: 'Umbrella High-Gain Antenna',
        partCode: 'Gold-Plated Wire Mesh Dish',
        spec: '0.96 m diameter · S-Band live video link',
        story:
          'This delicate foldable mesh umbrella beamed live color television directly from Hadley Rille back into living rooms on Earth.',
      },
      camera: {
        title: 'Remote-Controlled RCA TV Camera',
        partCode: 'Lunar Communications Relay Unit (LCRU)',
        spec: 'Ground-commanded pan/tilt color camera',
        story:
          'The robotic eye that watched Falcon blast off into the black lunar sky—its lens remains aimed at the empty descent stage.',
      },
      wheels: {
        title: 'Woven Piano-Wire Mesh Wheels',
        partCode: 'Boeing / Delco Zinc-Coated Mesh',
        spec: '81 cm diameter · Titanium chevron treads',
        story:
          'Rubber tires would fail in vacuum and extreme cold, so engineers wove springy steel mesh hoops that flex softly over lunar boulders.',
      },
      seats: {
        title: 'Dual Tubular Mesh Seats',
        partCode: 'Aluminum Frame & Restraint Straps',
        spec: 'Engineered for 1/6th lunar gravity',
        story:
          'Two dusty open-air seats where Scott and Irwin sat in bulky pressurized A7LB spacesuits.',
      },
    },
  },
  'apollo-17-challenger': {
    name: 'Challenger (LM-12) & Taurus-Littrow',
    subtitle: 'Humanity’s final lunar footsteps and the orange volcanic glass trench',
    bodyLabel: 'Moon',
    crewOrTeam: 'Eugene Cernan, Harrison Schmitt, Ronald Evans',
    abandonedDate: 'December 14, 1972 · 22:54 UTC',
    distanceLabel: '384,400 km',
    dimensions: '4.22 m height · 9.45 m footpad span',
    statusNote: 'Forward strut plaque stands as humanity’s latest signature on the Moon since 1972',
    photoCaption:
      'Fig. 3 — Challenger’s golden descent stage framed against the towering massifs of Taurus-Littrow, flanked by LRV-3 tracks and Shorty Crater’s orange glass beads.',
    storyOpening:
      'In December 1972, the first trained geologist set foot on another world. Driving 35.9 kilometers across the towering Taurus-Littrow valley, Harrison Schmitt and commander Eugene Cernan kicked aside gray dust at Shorty Crater and gasped: sparkling beneath the surface lay vivid orange microscopic spheres of ancient volcanic glass.',
    storyContinuation:
      'Minutes before liftoff on December 14, 1972, Eugene Cernan knelt beside LRV-3 and traced his daughter Tracy’s initials (“TDC”) in the lunar soil, then spoke humanity’s closing words from the ladder. As Challenger’s upper cabin rose, its golden base stayed behind in the shadow of peaks taller than Everest.',
    storyLegacy:
      'Decades later, modern micro-analysis of Apollo 17’s orange glass beads revealed the Moon’s deep interior held a hundred times more water than once believed. Meanwhile, in a world without wind or rain, Cernan’s carved initials and bootprints could endure undisturbed for hundreds of thousands of years.',
    pullQuote:
      '“We leave as we came and, God willing, as we shall return, with peace and hope for all mankind.”',
    pullQuoteAttribution: 'Eugene Cernan, last human words on the Moon, Dec 14, 1972',
    finalTransmission: {
      timestamp: '14 DEC 1972 · 22:54:37 UTC',
      message: '“Okay, let’s light this fire and get out of this dusty neighborhood!”',
      context:
        'Houston tilted LRV-3’s camera skyward one final time as Challenger vanished into the black lunar sky.',
    },
    environment: {
      tempRange: '-175 °C / +121 °C',
      gravity: '1.62 m/s² (0.165 g)',
      signalDelay: '1.28 seconds',
      hazard: 'Reflected thermal glare from steep valley massifs and abrasive dust',
    },
    orbitalObservation:
      'High-resolution LRO imagery from 2011 clearly resolves Challenger, the parked LRV-3 rover, the ALSEP science cluster, and crisp double-boot tracks.',
    scientificBreakthroughs: [
      '3.64-billion-year-old orange pyroclastic beads at Shorty Crater proved water existed deep in the lunar mantle.',
      'Recovered 110.5 kg of lunar rocks—the largest extraterrestrial geological archive of any Apollo flight.',
      'Taurus-Littrow gravimeter and seismic arrays mapped crust thickness beneath volcanic highlands.',
    ],
    leftBehindItems: [
      {
        name: '“TDC” Dust Engraving',
        detail:
          'Three initials Eugene Cernan wrote in the fine regolith for his daughter Tracy right before climbing the ladder.',
      },
      {
        name: 'December 1972 Closing Plaque',
        detail:
          'Stainless-steel plaque reading: “Here Man completed his first explorations of the Moon, December 1972 A.D.”',
      },
      {
        name: 'Goodwill Moon Rock Slices',
        detail:
          'Fragments cut from returned basalt sample 70017 were gifted to 135 nations worldwide.',
      },
    ],
    xraySummary:
      'Challenger’s J-series descent stage featured expanded oxygen, water, and battery bays plus a reinforced Quadrant-1 bay built to carry LRV-3 across a 75-hour lunar stay.',
    weatheringStages: {
      early:
        '1972: LRV-3 parked safely beyond blast range; crisp footprints cast razor-sharp shadows.',
      mid: '2000: Three decades of micrometeoroids speckled the crinkled golden Kapton shrouds.',
      present:
        '2026: Both Challenger and LRV-3 140 meters east remain clearly visible in orbital passes.',
    },
    hotspots: {
      kapton17: {
        title: 'Extended J-Series Kapton Frame',
        partCode: 'LM-12 Reinforced Descent Stage',
        spec: 'Expanded consumables for 3-day valley expedition',
        story:
          'Golden multi-layer foil wrapping enlarged oxygen and water tanks built to sustain the longest Apollo surface stay.',
      },
      'orange-soil': {
        title: 'Orange Volcanic Glass Sample Site',
        partCode: 'Shorty Crater Pyroclastic Vein',
        spec: '3.64-billion-year-old titanium-rich glass beads',
        story:
          'Sparked Harrison Schmitt’s famous shout—“There is orange soil!”—and rewrote the story of lunar water and volcanism.',
      },
      plaque17: {
        title: '“December 1972” Closing Plaque',
        partCode: 'Forward Ladder · Stainless Steel',
        spec: 'Final Apollo crew commemorative plate',
        story:
          'Mounted on the forward strut as humanity’s closing signature on the lunar frontier.',
      },
      alsep17: {
        title: 'ALSEP Science Station & Seismometers',
        partCode: 'SNAP-27 Nuclear Surface Package',
        spec: 'Transmitted continuously to Earth until 1977',
        story:
          'Kept measuring lunar heat flow, seismic tremors, and thin atmospheric gases for five years after Challenger departed.',
      },
    },
  },
  'surveyor-3': {
    name: 'Surveyor 3 Lunar Probe',
    subtitle: 'The only robot on another world ever visited and sampled by astronauts',
    bodyLabel: 'Moon',
    crewOrTeam: 'JPL Surveyor Team · Visited by Pete Conrad & Alan Bean',
    abandonedDate: 'May 3, 1967 (Silent) · Nov 20, 1969 (Visited)',
    distanceLabel: '384,400 km',
    dimensions: '3.00 m height · 4.27 m footpad span',
    statusNote: 'TV camera was removed by Apollo 12 and returned to Earth; frame remains in crater',
    photoCaption:
      'Fig. 4 — Apollo 12 astronauts found the 2.5-year-old Surveyor 3 resting intact on the 14-degree inner slope of Surveyor Crater.',
    storyOpening:
      'Landing inside a small crater in the Ocean of Storms in April 1967, Surveyor 3 bounced twice when its radar briefly lost lock, then snapped 6,315 photographs before freezing during its first two-week lunar night. Its story might have ended there—until two humans walked down the crater rim two and a half years later.',
    storyContinuation:
      'In November 1969, Apollo 12 astronauts Pete Conrad and Alan Bean landed within walking distance of the silent probe. Strolling 163 meters down the crater wall, they inspected the dust-coated white tripod and used surgical shears to detach its television camera for return to Earth. Missing its robotic eye, Surveyor 3 still keeps watch on the crater slope.',
    storyLegacy:
      'Microscopic analysis of foam inside the returned camera sparked decades of astrobiology debate over whether terrestrial bacteria (Streptococcus mitis) survived 31 months in lunar vacuum—later re-evaluated as likely cleanroom contamination—yet established the first true forensic study of off-world spacecraft aging.',
    pullQuote:
      '“A neighborly visit to a machine sleeping alone for two and a half years: humanity’s first off-world salvage.”',
    pullQuoteAttribution: 'Apollo 12 Surface EVA Report',
    finalTransmission: {
      timestamp: '03 MAY 1967 · 00:04 UTC',
      message: '“Frame 6,315 transmitted. Lunar sunset commencing; thermal bus declining.”',
      context:
        'Surveyor 3 powered down as freezing lunar darkness fell and never responded to wake-up calls.',
    },
    environment: {
      tempRange: '-180 °C / +115 °C',
      gravity: '1.62 m/s² (0.165 g)',
      signalDelay: '1.28 seconds',
      hazard: 'Steep 14° crater slope and solar paint darkening',
    },
    orbitalObservation:
      'LRO orbital frames capture both the tiny white triangle resting on Surveyor Crater’s inner slope and Apollo 12’s Intrepid descent stage 163 meters to the northwest.',
    scientificBreakthroughs: [
      'Pantograph soil scoop proved lunar regolith was firm enough to bear heavy crewed Apollo landers.',
      'Gave engineers the first laboratory specimen of circuits and optics aged 31 months in lunar vacuum.',
      'Apollo 12’s pinpoint 163-meter walk demonstrated precision landing navigation for future missions.',
    ],
    leftBehindItems: [
      {
        name: 'Extended Pantograph Soil Arm',
        detail:
          'Still poised above the four miniature trenches it dug in 1967 to measure lunar soil bearing strength.',
      },
      {
        name: 'Sandblasted White Paint',
        detail:
          'Exhaust dust kicked up by Intrepid’s nearby landing scoured one flank of Surveyor’s white frame to tanned bronze.',
      },
      {
        name: 'Snipped Camera Harness',
        detail:
          'Silver-Teflon wiring harnesses cleanly sheared by Pete Conrad’s metal cutters remain dangling on the mast.',
      },
    ],
    xraySummary:
      'Inside the triangular aluminum spaceframe sit three Vernier throttleable thrusters, crushable honeycomb footpads, and foam-insulated electronics compartments.',
    weatheringStages: {
      early:
        '1967: Crisp white thermal paint reflected harsh sunlight while its scoop dug four soil trenches.',
      mid: '1969: Apollo 12 crews observed the white paint had tanned to a warm dusty gray-brown.',
      present:
        '2026: While its camera sits in a museum in Washington, the headless tripod still anchors itself in the crater dust.',
    },
    hotspots: {
      solar: {
        title: 'Vertical Solar Panel Mast',
        partCode: '85 W Photovoltaic Array',
        spec: '0.85 m² area · 3,960 silicon cells',
        story:
          'Designed to power daytime photography, though the battery never survived the -180 °C freeze of the first lunar night.',
      },
      'camera-gap': {
        title: 'Empty TV Camera Mount',
        partCode: 'Apollo 12 Sample Retrieval Site',
        spec: 'Detached by Alan Bean in Nov 1969',
        story:
          'Removed after 31 months on the Moon so scientists could measure how vacuum and radiation age spacecraft alloys.',
      },
      scoop: {
        title: 'Pantograph Soil Sampler Scoop',
        partCode: 'SMSS Mechanical Arm',
        spec: '1.5 m reach · First lunar trenching tool',
        story:
          'Dug tiny trenches into the lunar soil to prove the surface could safely support the weight of future Apollo landers.',
      },
      tripod: {
        title: 'Tubular Tripod & Crushable Pads',
        partCode: '7075 Aluminum Truss',
        spec: 'Anchored on a 14° crater slope',
        story:
          'Its honeycomb footpads absorbed two unexpected landing bounces and still rest inside those faint 1967 impact dimples.',
      },
    },
  },
  'viking-1': {
    name: 'Viking 1 Mars Lander',
    subtitle: 'Mars’s first long-term ambassador, silenced forever by a single faulty command',
    bodyLabel: 'Mars',
    crewOrTeam: 'NASA Langley & JPL · Tim Mutch Imaging Team',
    abandonedDate: 'November 13, 1982 (Last Signal)',
    distanceLabel: '≈ 225 million km',
    dimensions: '2.10 m height · 3.00 m width',
    statusNote: 'Plutonium RTGs still radiate faint warmth; high-gain dish lost Earth lock',
    photoCaption:
      'Fig. 5 — Captured in the summer of 1976, showing Viking 1’s dust-speckled deck and sampling arm reaching across Chryse Planitia.',
    storyOpening:
      'Touching down on Chryse Planitia on July 20, 1976, Viking 1 became the first spacecraft to operate long-term on Mars, sending crystal-clear panoramas and daily weather reports. Built for a 90-day mission, it endured for 2,245 Martian sols—over six Earth years. Yet its end came not from a dust storm or hardware failure, but from a single human software mistake.',
    storyContinuation:
      'In November 1982, engineers uploaded a routine memory patch to improve battery charging. Tragically, the patch overwrote data used to calculate the pointing angle of the high-gain dish antenna. The dish slewed away from Earth, severing contact permanently. Today Viking 1 rests half-drifted in iron-oxide sand at Thomas Mutch Memorial Station.',
    storyLegacy:
      'Viking 1’s Labeled Release biology chamber produced an intriguing metabolic-like spike that still sparks scientific debate nearly fifty years later. Heat-sterilized at 111 °C before launch so no terrestrial microbe could hitch a ride, it remains the foundational monument of planetary protection and Martian meteorology.',
    pullQuote:
      '“After listening to Martian winds for six years, the station was deafened by a single misplaced block of code from Earth.”',
    pullQuoteAttribution: 'JPL Viking End-of-Mission Report, 1983',
    finalTransmission: {
      timestamp: '11 NOV 1982 · 23:02 UTC (SOL 2245)',
      message:
        '“Pressure: 7.4 millibars · Sunset approaching · Updating memory block 4401...”',
      context:
        'Immediately after this patch upload, antenna pointing memory was overwritten; contact ceased two days later.',
    },
    environment: {
      tempRange: '-107 °C / -17 °C',
      gravity: '3.72 m/s² (0.38 g)',
      signalDelay: '4–22 minutes (one-way)',
      hazard: 'Seasonal global dust storms and ferric oxide accumulation',
    },
    orbitalObservation:
      'MRO’s HiRISE camera photographed Viking 1 on Chryse Planitia in 2006, spotting its 1.5-meter metallic shadow alongside its jettisoned aeroshell nearby.',
    scientificBreakthroughs: [
      'Delivered the first crisp, color surface panoramas from another planet in the solar system.',
      'Recorded a 6-year meteorological log revealing Mars’s seasonal atmospheric pressure swings.',
      'Performed humanity’s first direct robotic biology and organic-chemistry assays on Martian soil.',
    ],
    leftBehindItems: [
      {
        name: 'Thomas A. Mutch Memorial Plaque',
        detail:
          'Officially dedicated in 1981 to honor the late Viking imaging team leader Tim Mutch.',
      },
      {
        name: 'SNAP-19 Plutonium Power Cores',
        detail:
          'With an 87.7-year half-life, these two cylinders remain noticeably warm in the freezing Martian night 44 years later.',
      },
      {
        name: 'Trenches Beside “Big Joe” Boulder',
        detail:
          'Small sampling excavations dug in 1976, now softened by decades of Martian wind drift.',
      },
    ],
    xraySummary:
      'Flanking the hexagonal biology laboratory are twin SNAP-19 Plutonium-238 radioisotope thermoelectric generators (RTGs). With an 87.7-year half-life, they still keep the core faintly warm today.',
    weatheringStages: {
      early:
        '1976: Bright metallic deck panels began collecting their first fine dusting of red Martian silt.',
      mid: '1999: Over two decades of thin wind steadily banked small sand drifts against the three footpads.',
      present:
        '2026: Spotted from orbit by MRO as a tiny dark speck casting a faint shadow across the Golden Plain.',
    },
    hotspots: {
      dish: {
        title: 'Misaligned S-Band Parabolic Dish',
        partCode: '0.76 m High-Gain Antenna',
        spec: 'Locked off-axis by faulty memory patch',
        story:
          'The silent point of failure: pointed away from Earth’s sky ever since the November 1982 software upload.',
      },
      rtg: {
        title: 'SNAP-19 Nuclear Power Cylinders',
        partCode: 'Plutonium-238 RTG Pair',
        spec: '70 W initial output · 87.7-year half-life',
        story:
          'Immune to dust storms, these finned cylinders still emit gentle radioactive warmth into the frigid Martian night.',
      },
      arm: {
        title: 'Biology Soil-Sampling Arm',
        partCode: '3 m Retractable Collector Boom',
        spec: 'First robotic arm to test Martian soil for life',
        story:
          'Scooped soil beside the “Big Joe” boulder, initiating humanity’s first direct search for extraterrestrial microbes.',
      },
      body: {
        title: 'Hexagonal Sterilized Chassis',
        partCode: 'Aluminum-Titanium Biology Lab',
        spec: 'Dry-heat sterilized at 111 °C before launch',
        story:
          'Baked before leaving Earth to protect Mars from terrestrial microbes; designated Thomas Mutch Memorial Station.',
      },
    },
  },
  sojourner: {
    name: 'Sojourner & Pathfinder',
    subtitle: 'The 10-kilogram rover that circled its silent mother station until sleep',
    bodyLabel: 'Mars',
    crewOrTeam: 'JPL · Donna Shirley, Brian Cooper & Jake Matijevic Team',
    abandonedDate: 'September 27, 1997 (Sol 83)',
    distanceLabel: '≈ 191 million km',
    dimensions: '65 cm length · 48 cm width · 30 cm height',
    statusNote: 'Autonomous failsafe likely kept it circling Carl Sagan Memorial Station',
    photoCaption:
      'Fig. 6 — Microwave-sized Sojourner pressing its alpha-proton spectrometer against the Martian boulder nicknamed “Yogi” in Ares Vallis.',
    storyOpening:
      'Bouncing to a stop inside giant airbags on July 4, 1997, Mars Pathfinder unfolded its petals to release a microwave-sized pioneer: Sojourner. As the first wheeled robot to rove another planet, it drove roughly 100 meters in total—yet proved that Ares Vallis had once been swept by catastrophic ancient floods.',
    storyContinuation:
      'On September 27, 1997, the Pathfinder base station’s main battery finally succumbed to Martian cold. Because Sojourner could not talk directly to Earth, its software held an autonomous contingency rule: if contact with the lander is lost, drive in slow circles around it while searching for a signal. Engineers believe the little rover kept circling its silent mother until its own batteries froze.',
    storyLegacy:
      'Named after abolitionist Sojourner Truth, this 10-kilogram pioneer launched NASA’s modern era of robotic rovers—passing its patented six-wheel Rocker-Bogie suspension directly down to Spirit, Opportunity, Curiosity, and Perseverance.',
    pullQuote:
      '“Waiting for an answer that never came, the tiny rover circled its silent mother station until sleep overtook it.”',
    pullQuoteAttribution: 'Mars Pathfinder Engineering Recollections',
    finalTransmission: {
      timestamp: '27 SEP 1997 · 10:23 UTC (SOL 83)',
      message:
        '“IMP telemetry carrier lost. Rover entering autonomous base-search loop.”',
      context:
        'Pathfinder’s final signal; all recovery attempts throughout October 1997 met silence.',
    },
    environment: {
      tempRange: '-110 °C / -10 °C',
      gravity: '3.72 m/s² (0.38 g)',
      signalDelay: '10.6 minutes',
      hazard: 'Solar deck dust accumulation and lithium cell freezing',
    },
    orbitalObservation:
      'MRO HiRISE views of Ares Vallis resolve Carl Sagan Memorial Station’s triangular open petals and deflated landing airbags nearby.',
    scientificBreakthroughs: [
      'Rounded pebbles stacked together in Ares Vallis proved mega-floods once surged across Mars.',
      'Validated six-wheel Rocker-Bogie mobility over sharp alien rocks for the first time.',
      'Beamed back 16,500 lander images and 550 rover close-ups, igniting modern Mars exploration.',
    ],
    leftBehindItems: [
      {
        name: 'Carl Sagan Memorial Station',
        detail:
          'Three-petal tetrahedral lander platform renamed in memory of astronomer Carl Sagan after his passing in 1996.',
      },
      {
        name: '300,000-Name Silicon Microchip',
        detail:
          'Carried public signatures collected through The Planetary Society into eternal Martian rest.',
      },
      {
        name: 'Wheel Tracks at “Yogi” Rock',
        detail:
          'Tiny 13 cm cleat prints impressed beside the boulders studied by the APXS sensor.',
      },
    ],
    xraySummary:
      'Inside its aerogel-insulated Warm Electronics Box lives an Intel 80C85 processor—roughly the computing power of an early home computer—paired with non-rechargeable lithium backup cells.',
    weatheringStages: {
      early:
        '1997: The dark gallium-arsenide solar deck gleamed cleanly as six little aluminum wheels etched crisp tracks.',
      mid: '2010: Annual Martian dust devils gradually coated both rover and lander petals in uniform rust.',
      present:
        '2026: Resting only a few meters from Carl Sagan Memorial Station beneath drifting wind-blown sand.',
    },
    hotspots: {
      'solar-deck': {
        title: 'GaAs Solar Panel Deck',
        partCode: '16 W Gallium Arsenide Array',
        spec: '0.22 m² area · Daytime-only drive power',
        story:
          'Generating barely enough wattage to light a small household bulb, this slim plate powered 83 sols of historic exploration.',
      },
      apxs: {
        title: 'APXS Rock-Sniffing Spectrometer',
        partCode: 'Alpha Proton X-Ray Spectrometer',
        spec: 'Presses flush against boulders to read chemistry',
        story:
          'Touched Barnacle Bill and Yogi rocks to reveal Mars’s volcanic and water-altered past.',
      },
      bogie: {
        title: 'Rocker-Bogie Suspension',
        partCode: '6-Wheel Articulated Drive',
        spec: '13 cm aluminum wheels · Stainless cleats',
        story:
          'Capable of climbing obstacles larger than its own wheels—a mechanical blueprint inherited by Spirit, Opportunity, Curiosity, and Perseverance.',
      },
      antenna: {
        title: 'Short-Range UHF Whip Antenna',
        partCode: 'Pathfinder Relay Link',
        spec: '9,600 bps modem · 15 m effective range',
        story:
          'Never heard Earth directly; every discovery had to be whispered across a few meters to Carl Sagan Station.',
      },
    },
  },
  opportunity: {
    name: 'Opportunity (MER-B)',
    subtitle: 'Sent for 90 days, endured 14 years before the great dust storm’s twilight',
    bodyLabel: 'Mars',
    crewOrTeam: 'JPL · Steve Squyres, John Callas & Rover Driving Team',
    abandonedDate: 'June 10, 2018 (Last Signal) · Feb 13, 2019 (Farewell)',
    distanceLabel: '≈ 205 million km',
    dimensions: '1.60 m length · 2.30 m width · 1.50 m height',
    statusNote: 'Set the off-world driving record of 45.16 km before stopping in Perseverance Valley',
    photoCaption:
      'Fig. 7 — Looking back along Opportunity’s winding wheel tracks across Perseverance Valley as the 2018 global dust storm turned midday into amber twilight.',
    storyOpening:
      'Landing squarely inside Eagle Crater on Meridiani Planum in January 2004, Opportunity was built to survive just 90 Martian days. Instead, Martian gusts periodically swept dust off its solar wings, granting it over fourteen years of life and an off-world marathon record of 45.16 kilometers.',
    storyContinuation:
      'In May 2018, a planet-encircling dust storm blotted out the Sun, turning high noon as black as midnight. On June 10, 2018, Opportunity sent its final telemetry packet: solar power had collapsed and the clock was drifting. For eight months, NASA beamed daily wake-up songs across the void—ending on February 13, 2019 with Billie Holiday’s “I’ll Be Seeing You.”',
    storyLegacy:
      'Discovering tiny hematite “blueberries” and clay minerals across Eagle and Endeavour craters, Opportunity proved ancient Mars once held surface water compatible with life. Resting quietly under a blanket of storm dust, it remains an enduring emblem of engineering resilience.',
    pullQuote: '“My battery is low and it’s getting dark.”',
    pullQuoteAttribution: 'Poetic distillation of Opportunity’s final telemetry, June 10, 2018',
    finalTransmission: {
      timestamp: '10 JUN 2018 · SOL 5111',
      message: '“Solar array energy: 22 Wh · Atmospheric Tau: 10.8 · Darkness falling.”',
      context:
        'Following this downlinked packet, the rover entered low-power fault sleep and never awoke.',
    },
    environment: {
      tempRange: '-100 °C / +20 °C',
      gravity: '3.72 m/s² (0.38 g)',
      signalDelay: '11.4 minutes',
      hazard: 'Planet-encircling dust opacity and unheated clock drift',
    },
    orbitalObservation:
      'In September 2018, as the global storm cleared, MRO HiRISE spotted Opportunity parked silently on the inner slope of Perseverance Valley along Endeavour Crater.',
    scientificBreakthroughs: [
      'Identified hematite “blueberries” and gypsum veins formed directly in ancient liquid water.',
      'Set humanity’s all-time off-world distance record at 45.16 kilometers—longer than an earthly marathon.',
      'Discovered neutral-pH clay minerals on Endeavour Crater’s rim, pointing to habitable ancient waters.',
    ],
    leftBehindItems: [
      {
        name: 'World Trade Center Steel Cuff',
        detail:
          'A protective aluminum cable shield on the Rock Abrasion Tool forged from steel recovered from the Twin Towers.',
      },
      {
        name: '4-Million-Name Mini-DVD',
        detail:
          'A silica glass DVD mounted to the lander base bearing four million Earth signatures.',
      },
      {
        name: '45-Kilometer Track Trail',
        detail:
          'A winding trail connecting Eagle, Endurance, Victoria, and Endeavour craters still faintly etched in orbital views.',
      },
    ],
    xraySummary:
      'Inside its gold-insulated Warm Electronics Box sit a radiation-hardened RAD6000 processor, dual lithium-ion battery packs, and eight tiny plutonium radioisotope heater units (RHUs).',
    weatheringStages: {
      early:
        '2004: Clean bat-wing solar arrays gleamed brightly as Opportunity studied dark hematite “blueberries.”',
      mid: '2012: Beyond 30 km driven; despite a stiff front steering actuator, it tackled crater rims in reverse.',
      present:
        '2026: Resting quietly on the slope of Perseverance Valley beneath a thick blanket of 2018 storm dust.',
    },
    hotspots: {
      pancam: {
        title: 'Pancam Stereo Eyes',
        partCode: '1.5 m Mast Camera Head',
        spec: 'Captured over 228,000 Martian images',
        story:
          'Measured the thickening storm opacity right before sending its final noisy thumbnail of a darkened sun.',
      },
      wings: {
        title: 'Triangular Solar Wing Array',
        partCode: 'Triple-Junction Photovoltaic Wings',
        spec: '900 Wh launch peak → 22 Wh final sol',
        story:
          'Kept alive for 14 years thanks to lucky Martian wind “cleaning events” until the 2018 global storm overwhelmed them.',
      },
      idd: {
        title: 'IDD Robotic Arm & Rock Abrasion Tool',
        partCode: 'Instrument Deployment Device (RAT)',
        spec: 'Microscopic imager + dual spectrometers',
        story:
          'Ground 5-millimeter holes into bedrock, proving liquid water once soaked Meridiani Planum.',
      },
      'wheels-opp': {
        title: '45.16-Kilometer Aluminum Wheels',
        partCode: '6 Independent Rocker-Bogie Wheels',
        spec: 'Longest off-world drive in history (45,160 m)',
        story:
          'Twice freed from treacherous sand ripples over weeks of testing, finally coming to rest in Perseverance Valley.',
      },
    },
  },
  insight: {
    name: 'InSight Mars Lander',
    subtitle: 'The seismic ear that listened to 1,319 marsquakes before red dust settled over its wings',
    bodyLabel: 'Mars',
    crewOrTeam: 'JPL & CNES / DLR · Bruce Banerdt & Seismology Team',
    abandonedDate: 'December 15, 2022 (Last Signal)',
    distanceLabel: '≈ 210 million km',
    dimensions: '6.00 m solar span · 1.08 m height',
    statusNote: 'Circular solar wings blanketed in red dust; copper-domed SEIS rests on the dirt',
    photoCaption:
      'Fig. 8 — InSight’s final self-portrait transmitted on its last watts of power in December 2022, showing the dust-coated solar deck and copper SEIS dome.',
    storyOpening:
      'Landing on the flat, rock-free plain of Elysium Planitia in November 2018—jokingly nicknamed “the biggest parking lot on Mars”—InSight was a stationary planetary physician. Using its robotic arm, it placed a hyper-sensitive seismometer directly onto the Martian dirt and heard the planet’s hidden pulse: 1,319 marsquakes and meteorite impacts.',
    storyContinuation:
      'Unlike windy Jezero or Meridiani, Elysium Planitia offered few dust-clearing gusts. Over four years, fine iron-oxide silt blanketed its twin circular solar arrays. Engineers shut down every secondary instrument so the SEIS seismometer could listen until the very end. On December 15, 2022, InSight whispered home: “My power’s really low, so this may be the last image I can send.”',
    storyLegacy:
      'InSight drew the first cross-section of Mars’s deep interior—revealing a liquid metallic core roughly 1,830 kilometers in radius beneath a three-layered crust. Right beside it, the stubborn German-built HP3 “mole” thermal probe still rests half-buried in hardpan crust after two years of hammering in place.',
    pullQuote:
      '“My power’s really low, so this may be the last image I can send. Don’t worry about me though: my time here has been both productive and serene.”',
    pullQuoteAttribution: 'InSight Mission Farewell Message, December 2022',
    finalTransmission: {
      timestamp: '15 DEC 2022 · SOL 1440',
      message: '“SEIS telemetry offline. Daily energy below 285 Wh; farewell selfie downlinked.”',
      context:
        'Following two unanswered radio calls on December 18 and 21, NASA formally retired the station.',
    },
    environment: {
      tempRange: '-99 °C / -18 °C',
      gravity: '3.72 m/s² (0.38 g)',
      signalDelay: '11.8 minutes',
      hazard: 'Low-wind equatorial dust buildup choking photovoltaic wings',
    },
    orbitalObservation:
      'MRO HiRISE imagery from May 2023 confirmed InSight and its SEIS wind shield have faded to nearly the exact rust hue of the surrounding desert.',
    scientificBreakthroughs: [
      'Detected over 1,319 marsquakes, proving Mars remains seismically and tectonically alive.',
      'Measured the planet’s liquid metallic core radius (≈ 1,830 km) and crust thickness for the first time.',
      'Captured acoustic and seismic shockwaves from fresh meteoroid crater impacts.',
    ],
    leftBehindItems: [
      {
        name: '2.4-Million-Name Silicon Microchips',
        detail:
          'Two etched microchips bolted onto InSight’s deck preserve more than 2.4 million names from Earth.',
      },
      {
        name: 'The Stubborn HP3 “Mole” Probe',
        detail:
          'Designed to burrow 5 meters deep, the 40 cm self-hammering nail wrestled frictionless soil for two years beside the lander.',
      },
      {
        name: 'Copper Wind & Thermal Shield (WTS)',
        detail:
          'White-and-copper dome placed carefully over SEIS so Martian breezes wouldn’t mask tiny deep-mantle tremors.',
      },
    ],
    xraySummary:
      'Inside the octagonal lander body sit the French-UK seismometer electronics, UHF relay radio, and dual 25 Ah lithium-ion batteries wired via a flat kapton ribbon tether to the external SEIS dome.',
    weatheringStages: {
      early:
        '2018: Twin 2.15 m decagonal solar wings gleamed dark blue, generating 4,588 Wh per Martian day.',
      mid: '2021: Flight controllers scooped sand onto the panel edges so passing breezes helped sweep loose dust away.',
      present:
        '2026: Wings have blended almost seamlessly into the surrounding ochre plain as a quiet geophysical monument.',
    },
    hotspots: {
      seis: {
        title: 'SEIS Seismometer & Copper Dome',
        partCode: 'CNES Tri-Axial Vacuum Seismometer',
        spec: 'Detects ground vibrations smaller than one atom',
        story:
          'The first seismometer set directly onto another planet’s soil, recording 1,319 marsquakes.',
      },
      'solar-wings': {
        title: 'Decagonal UltraFlex Solar Wings',
        partCode: '2.15 m Circular Folding Arrays',
        spec: '4,588 Wh peak output → <285 Wh final sol',
        story:
          'Twin ten-sided solar fans whose gradual burial under calm Elysium dust sealed the mission’s lifespan.',
      },
      'arm-insight': {
        title: 'IDA Robotic Deployment Arm',
        partCode: '2.4 m Four-Jointed Grapple Crane',
        spec: 'Placed SEIS & HP3; poured sand to clean dust',
        story:
          'Engineers famously used its scoop to trickle coarse sand beside the wings, letting wind gusts knock off fine red silt.',
      },
      mole: {
        title: 'HP3 “Mole” Heat-Flow Probe',
        partCode: 'DLR Self-Hammering Thermal Spike',
        spec: 'Target: 5 m depth · Achieved: ~40 cm',
        story:
          'Battled unexpectedly cemented “duricrust” Martian dirt for two years—earning worldwide affection as the little probe that tried.',
      },
    },
  },
};

export function getLocalizedArtifact(artifact: Artifact, lang: Language): Artifact {
  if (lang === 'tr') return artifact;
  const en = ARTIFACTS_EN[artifact.id];
  if (!en) return artifact;
  return {
    ...artifact,
    name: en.name,
    subtitle: en.subtitle,
    bodyLabel: en.bodyLabel,
    crewOrTeam: en.crewOrTeam,
    abandonedDate: en.abandonedDate,
    distanceLabel: en.distanceLabel,
    dimensions: en.dimensions,
    statusNote: en.statusNote,
    photoCaption: en.photoCaption,
    storyOpening: en.storyOpening,
    storyContinuation: en.storyContinuation,
    storyLegacy: en.storyLegacy,
    pullQuote: en.pullQuote,
    pullQuoteAttribution: en.pullQuoteAttribution,
    finalTransmission: en.finalTransmission,
    environment: en.environment,
    orbitalObservation: en.orbitalObservation,
    scientificBreakthroughs: en.scientificBreakthroughs,
    leftBehindItems: en.leftBehindItems,
    xraySummary: en.xraySummary,
    weatheringStages: en.weatheringStages,
    hotspots: artifact.hotspots.map((hs) => {
      const hsEn = en.hotspots[hs.id];
      return hsEn ? { ...hs, ...hsEn } : hs;
    }),
  };
}
