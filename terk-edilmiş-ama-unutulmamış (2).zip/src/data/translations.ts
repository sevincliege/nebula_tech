export type Language = 'tr' | 'en';

export interface CuratorialThemeItem {
  id: 'weathering' | 'humanity' | 'preservation';
  tabLabel: string;
  kicker: string;
  title: string;
  lead: string;
  paragraphs: string[];
  comparisonTitle: string;
  comparisons: Array<{
    subject: string;
    detail: string;
  }>;
  keyTakeaway: string;
}

export interface UITranslations {
  docTitle: string;
  brand: string;
  nav: {
    map: string;
    studio: string;
    themes: string;
    catalog: string;
    timeline: string;
  };
  startStory: string;
  switchLangLabel: string;
  switchLangAria: string;
  hero: {
    kicker: string;
    title: string;
    subtitle: string;
    cta: string;
    stats: {
      scopeLabel: string;
      scopeValue: string;
      scopeDesc: string;
      inventoryLabel: string;
      inventoryValue: string;
      inventoryDesc: string;
      spanLabel: string;
      spanValue: string;
      spanDesc: string;
      distanceLabel: string;
      distanceValue: string;
      distanceDesc: string;
    };
  };
  map: {
    kicker: string;
    title: string;
    desc: string;
    moonTab: string;
    marsTab: string;
    moonProjection: string;
    marsProjection: string;
    moonDistance: string;
    marsDistance: string;
    chapterPrefix: string;
    yearsSilentSuffix: string;
    sinceText: (date: string, years: number) => string;
    coordsLabel: string;
    tempLabel: string;
    delayLabel: string;
    statusLabel: string;
    cta: string;
  };
  workshop: {
    kicker: string;
    chapterOf: string;
    totalChapters: string;
    dossierTabs: {
      narrative: string;
      relics: string;
      science: string;
    };
    relicsHeading: string;
    relicsIntro: string;
    scienceBreakthroughsHeading: string;
    orbitalVerificationHeading: string;
    crewTeamLabel: string;
    finalTxTitle: string;
    accessionTitle: string;
    siteLabel: string;
    abandonedLabel: string;
    massLabel: string;
    dimensionsLabel: string;
    statusNoteLabel: string;
    modelTitle: string;
    modelDesc3d: string;
    modelDesc2d: string;
    tab3d: string;
    tab2d: string;
    prevPrefix: string;
    nextPrefix: string;
  };
  viewer3d: {
    presets: {
      hero: string;
      front: string;
      top: string;
      detail: string;
    };
    sceneTag: string;
    dragHint: string;
    hideControls: string;
    showControls: string;
    explodeLabel: string;
    dustyLabel: string;
    autoOrbit: string;
    resetAria: string;
    resetTitle: string;
    webglFallback: string;
  };
  blueprint2d: {
    modeBlueprint: string;
    modeXray: string;
    modeWeathering: string;
    grid: string;
    zoomOutAria: string;
    zoomInAria: string;
    resetAria: string;
    orthographicTag: string;
    xrayTag: string;
    weatheringTag: string;
    timeSliderLabel: string;
    selectedYearLabel: (year: number, delta: number) => string;
    xrayNoteLabel: string;
    ascentDeparted: string;
    fuelLabel: string;
    oxidizerLabel: string;
    lrvBatteries: string;
    takenByApollo12: string;
    vikingInternal: string;
    sojournerInternal: string;
    oppInternal: string;
    challengerInternal: string;
    insightInternal: string;
  };
  photo: {
    fiducials: string;
    enlarge: string;
    enlargeAria: string;
    closeAria: string;
    loadError: string;
  };
  themesSection: {
    kicker: string;
    title: string;
    desc: string;
    takeawayLabel: string;
    items: CuratorialThemeItem[];
  };
  catalog: {
    kicker: string;
    title: string;
    desc: string;
    allTab: string;
    moonTab: string;
    marsTab: string;
    allStatuses: string;
    emptyTitle: string;
    emptyDesc: string;
    resetFilters: string;
    yearsSilentUnit: string;
    currentlyInspecting: string;
    openStory: string;
  };
  timeline: {
    kicker: string;
    title: string;
    desc: string;
    lastContact: string;
    goToChapter: string;
  };
  footer: {
    subtitle: string;
    top: string;
    map: string;
    studio: string;
    themes: string;
    catalog: string;
    timeline: string;
  };
  statusMap: Record<'Sessiz' | 'Yansıtıcı Aktif' | 'Toz Altında', string>;
}

export const TRANSLATIONS: Record<Language, UITranslations> = {
  tr: {
    docTitle: "Terk Edilmiş Ama Unutulmamış — Ay ve Mars'taki NASA Kalıntıları",
    brand: 'Sessiz Kalıntılar',
    nav: {
      map: 'Keşif Haritası',
      studio: '2D & 3D Atölye',
      themes: 'Koruma Mirası',
      catalog: 'Arşiv Koleksiyonu',
      timeline: 'Kronoloji',
    },
    startStory: 'Hikayeyi Başlat',
    switchLangLabel: 'English',
    switchLangAria: 'Dili İngilizceye çevir',
    hero: {
      kicker: 'Kozmik Arkeoloji Sergisi · Ay ve Mars (1967 – 2026)',
      title: 'Terk Edilmiş Ama Unutulmamış',
      subtitle:
        'İnsanlık Ay’a ayak bastıktan ve Mars’a tekerlek izleri bıraktıktan sonra eve döndü; ancak makinelerimiz orada kaldı. Rüzgarsız kraterlerde ve kızıl toz fırtınalarının altında uyuyan sekiz tarihi NASA mirasının hikayesini, kişisel emanetlerini, yörünge kanıtlarını, 2D çizimlerini ve 3D modellerini keşfedin.',
      cta: 'Keşfe Başla',
      stats: {
        scopeLabel: 'KEŞİF ALANI',
        scopeValue: '2 Gök Cismi',
        scopeDesc: 'Ay (Luna) ve Mars yüzeyi',
        inventoryLabel: 'ARŞİV ENVANTERİ',
        inventoryValue: '8 Tarihi Kalıntı',
        inventoryDesc: '2D, 3D modeller, eşyalar & kanıtlar',
        spanLabel: 'ZAMAN ARALIĞI',
        spanValue: '1967 – 2022',
        spanDesc: '59 yıla uzanan sessiz miras',
        distanceLabel: 'UZAKLIK ÖLÇEĞİ',
        distanceValue: '384 bin – 225M km',
        distanceDesc: 'Dünya’dan tek yön ışık mesafesi',
      },
    },
    map: {
      kicker: '01 · Selenografik & Areografik Harita',
      title: 'Sessizliğin Koordinatları',
      desc: 'Ay ve Mars haritaları üzerinde gezinin; her bir iniş noktasını seçerek orada bırakılan aracın hikayesini ve çevre koşullarını inceleyin.',
      moonTab: 'Ay (Luna) · 4 Kalıntı',
      marsTab: 'Mars · 4 Kalıntı',
      moonProjection: 'AY ÖN YÜZÜ · MERİDYEN PROJEKSİYONU',
      marsProjection: 'MARS EKİP HARİTASI · MERCATÖR PROJEKSİYONU',
      moonDistance: 'ORTALAMA MESAFE: 384.400 KM',
      marsDistance: 'ORTALAMA MESAFE: 225 MİLYON KM',
      chapterPrefix: 'BÖLÜM',
      yearsSilentSuffix: 'yıldır',
      sinceText: (date, years) =>
        `${date} tarihinden bu yana ${years} yıldır yerinde bekliyor.`,
      coordsLabel: 'Koordinatlar',
      tempLabel: 'Yüzey Sıcaklığı',
      delayLabel: 'Sinyal Gecikmesi',
      statusLabel: 'Mevcut Durum',
      cta: '2D / 3D Modeli ve Hikayeyi İncele',
    },
    workshop: {
      kicker: '02 · Hikaye, Eşyalar, 2D & 3D İnceleme Atölyesi',
      chapterOf: 'BÖLÜM',
      totalChapters: '08',
      dossierTabs: {
        narrative: 'Hikaye ve Miras',
        relics: 'Bırakılan Özel Eşyalar',
        science: 'Bilim ve Yörünge Kanıtı',
      },
      relicsHeading: 'İniş Sahasında Bırakılan Kişisel & Sembolik Eşyalar',
      relicsIntro:
        'Bu görevlerden geriye yalnızca metal gövdeler değil; astronotların ve mühendislerin insanlık adına bıraktığı sessiz hatıralar da kaldı.',
      scienceBreakthroughsHeading: 'Tarihe Geçen Bilimsel Bulgular',
      orbitalVerificationHeading: 'Yörünge Uydusu Gözlem Kanıtı',
      crewTeamLabel: 'Mürettebat / Mühendislik Ekibi',
      finalTxTitle: 'KAYDEDİLEN SON İLETİM',
      accessionTitle: 'Arşiv Künyesi ve Fiziksel Envanter',
      siteLabel: 'İniş Bölgesi',
      abandonedLabel: 'Terk Ediliş Tarihi',
      massLabel: 'Bırakılan Kütle',
      dimensionsLabel: 'Boyutlar',
      statusNoteLabel: 'Durum Notu',
      modelTitle: 'Etkileşimli 3D & 2D Model Atölyesi',
      modelDesc3d:
        'Aracı 360° döndürün, parça ayrımı sürgüsüyle katmanları inceleyin ve numaralı noktalara dokunarak o parçanın hikayesini okuyun.',
      modelDesc2d:
        '2D şema üzerindeki numaralı noktalara dokunun; iç yapıyı görmek için İç Yapı (Röntgen) veya yıllar içindeki değişim için Zaman Aşımı sekmesini seçin.',
      tab3d: '3D Etkileşimli Model',
      tab2d: '2D Teknik Çizim',
      prevPrefix: 'Önceki',
      nextPrefix: 'Sonraki',
    },
    viewer3d: {
      presets: {
        hero: 'Genel Açı',
        front: 'Ön Görünüm',
        top: 'Kuş Bakışı',
        detail: 'Yakın Detay',
      },
      sceneTag: '3D SAHNE',
      dragHint: 'Sürükle / Yakınlaştır',
      hideControls: 'Kontrolleri Gizle',
      showControls: 'Kontrolleri Göster',
      explodeLabel: 'Parça Ayrımı',
      dustyLabel: '2026 Tozlu',
      autoOrbit: 'Otomatik Dönüş',
      resetAria: '3D kamerayı sıfırla',
      resetTitle: 'Görünümü Sıfırla',
      webglFallback:
        'Tarayıcınızda 3D WebGL hızlandırması şu anda kullanılamıyor. Yukarıdaki sekmeden 2D Teknik Çizim görünümüne geçebilirsiniz.',
    },
    blueprint2d: {
      modeBlueprint: 'Teknik Çizim',
      modeXray: 'İç Yapı (Röntgen)',
      modeWeathering: 'Zaman Aşımı',
      grid: 'Izgara',
      zoomOutAria: 'Uzaklaştır',
      zoomInAria: 'Yakınlaştır',
      resetAria: 'Görünümü sıfırla',
      orthographicTag: 'ORTOGRAFİK 2D ŞEMA',
      xrayTag: 'İÇ SİSTEM KESİTİ',
      weatheringTag: 'YÜZEY AŞINIMI',
      timeSliderLabel: 'Zaman Çizelgesi Etkisi',
      selectedYearLabel: (year, delta) => `Seçili Yıl: ${year} (${delta} yıl sonra)`,
      xrayNoteLabel: 'İç Yapı Notu:',
      ascentDeparted: 'ÜST AŞAMA (AYRILDI)',
      fuelLabel: 'YAKIT',
      oxidizerLabel: 'OKSİDİZÖR',
      lrvBatteries: '2 × 36V GÜMÜŞ-ÇİNKO BATARYA',
      takenByApollo12: 'APOLLO 12 TARAFINDAN ALINDI',
      vikingInternal: 'GC-MS BİYOLOJİ DENEY MODÜLÜ · PU-238 ISITICI',
      sojournerInternal: '80C85 İŞLEMCİ · LİTYUM PİLLER · AEROJEL YALITIM',
      oppInternal: 'RAD6000 · 8× RHU ISITICI · Lİ-İYON',
      challengerInternal: 'GENİŞLETİLMİŞ O₂ & H₂O TANKLARI · LRV-3 KARGO YUVASI',
      insightInternal: 'CNES SEIS VAKUM KÜRESİ · 2× 25AH Lİ-İYON · UHF RÖLE',
    },
    photo: {
      fiducials: 'Ölçüm İşaretleri',
      enlarge: 'Büyüt',
      enlargeAria: 'Arşiv fotoğrafını tam ekran büyüt',
      closeAria: 'Tam ekran görünümü kapat',
      loadError: 'Arşiv görüntüsü yüklenemedi.',
    },
    themesSection: {
      kicker: '03 · Kozmik Arkeoloji ve Koruma Perspektifi',
      title: 'Bırakılanların Bilimi ve Koruma Mirası',
      desc: 'Ay’ın havasız boşluğu ile Mars’ın kızıl toz rüzgarları aynı makineleri bambaşka biçimlerde yaşlandırıyor; gelecekteki görevler ise bu ilk insanlık anıtlarını koruma sorumluluğuyla yüzleşiyor.',
      takeawayLabel: 'Arkeolojik Çıkarım',
      items: [
        {
          id: 'weathering',
          tabLabel: 'Aşınma Fiziği: Ay vs. Mars',
          kicker: 'TEMA 01 · ÇEVRESEL YAŞLANMA',
          title: 'Rüzgarsız Vakum ile Paslı Toz Fırtınalarının Savaşı',
          lead: 'Ay’da bıraktığımız araçlar asla paslanmaz ama her 14 günde bir 300 derecelik ısıl şokla kavrulur ve donar; Mars’takiler ise rüzgarın taşıdığı demir oksit zımparasıyla sessizce gömülür.',
          paragraphs: [
            'Ay yüzeyinde atmosfer olmadığı için ne rüzgar eser ne de boyayı kabartacak oksijen bulunur. Ancak güneş doğduğunda yüzey +127 °C’ye fırlarken Ay gecesinde -175 °C’ye çakılır. Bu acımasız genleşme-büzülme döngüsü, Eagle ve Challenger’ın altın Kapton folyolarının yapıştırıcılarını 50 yılda kırılganlaştırdı; Apollo bayraklarının renkli naylon ipliklerini ise filtrelenmemiş morötesi ışınlar tamamen bembeyaza ağarttı.',
            'Mars’ta ise sahneyi bambaşka bir fizik yönetir: ince karbondioksit atmosferi rüzgarları besler ve küresel toz fırtınaları kaldırır. Viking 1, Sojourner, Opportunity ve InSight bu nedenle pas rengi mikronluk hematit tozlarıyla kaplandı. Bazı gezginler şanslı rüzgar “temizleme olaylarıyla” yıllarca hayatta kalsa da sonunda güneş ışığını kesen o kızıl örtüye yenik düştü.',
          ],
          comparisonTitle: 'İki Dünyadaki Aşınma Mekanizmaları',
          comparisons: [
            {
              subject: 'Ay Yüzeyi (Apollo & Surveyor)',
              detail: 'Saniyede 20 km hızla çarpan mikrometeoritler metalde kratercik açar; ayak izleri en az 1 milyon yıl silinmez.',
            },
            {
              subject: 'Mars Yüzeyi (Viking, MER & InSight)',
              detail: 'Toz şeytanları ve mevsimsel kum taşınımı tekerlek izlerini birkaç on yılda siler, panelleri kalın silt ile örter.',
            },
            {
              subject: 'Radyoaktif Isı (RTG vs. Güneş Paneli)',
              detail: 'Plütonyum-238 taşıyan Viking 1 çekirdeği hâlâ ılıkken, güneş panelli InSight yalnızca toz yüzünden sustu.',
            },
          ],
          keyTakeaway:
            'Geleceğin uzay mühendisleri sadece iniş yapmayı değil, elektrik yüklü Ay tozunu ve yapışkan Mars kilini yüzeyden itebilecek elektrostatik kalkanları da tasarlamak zorunda.',
        },
        {
          id: 'humanity',
          tabLabel: 'Uzayda İnsanlık İzleri & Sanat',
          kicker: 'TEMA 02 · SESSİZ EMANETLER',
          title: 'Makine Gövdelerine İşlenmiş İnsan Hafızası',
          lead: 'Dünya dışına gönderilen her araç mühendislik harikası olduğu kadar bir veda mektubudur; üzerlerinde barış mesajları, anıt heykeller, aile hatıraları ve milyonlarca isim taşırlar.',
          paragraphs: [
            'Apollo astronotları Ay’a yalnızca sismometre değil insanlığın duygusal izlerini de bıraktı: Apollo 11 ekibi 73 ülke liderinin mesajını içeren bozuk para büyüklüğünde bir silisyum disk ve altın bir zeytin dalı bıraktı. Apollo 15’te David Scott, uzay yarışında hayatını kaybeden Amerikalı ve Sovyet meslektaşlarının anısına 8,5 santimetrelik alüminyum “Fallen Astronaut” heykelciğini Hadley vadisinin tozuna yatırdı.',
            'İnsansız robotik görevler de bu geleneği sürdürdü. Opportunity’nin kaya delici kolunun kablo kılıfı 11 Eylül’de yıkılan Dünya Ticaret Merkezi çeliklerinden dövüldü; Pathfinder üzerinde 300 bin, Opportunity üzerinde 4 milyon ve InSight güvertesinde tam 2,4 milyon Dünya vatandaşının adı yazılı mikroçipler hâlâ Mars ufkuna bakıyor.',
          ],
          comparisonTitle: 'Gezegen Dışı Anıt Envanteri',
          comparisons: [
            {
              subject: 'Apollo 17 · “TDC” Harfleri (1972)',
              detail: 'Eugene Cernan kızı Tracy’nin baş harflerini kalkıştan hemen önce parmağıyla Ay tozuna yazdı.',
            },
            {
              subject: 'Opportunity · İkiz Kuleler Çeliği (2004)',
              detail: 'Kaya Aşındırma Aracı (RAT) üzerindeki koruyucu alüminyum manşon anı metalinden üretildi.',
            },
            {
              subject: 'InSight & Pathfinder Mikroçipleri',
              detail: 'Milyonlarca insanın ismi lazerle kazınmış silikon plakalarla Mars toprağında kalıcılaştı.',
            },
          ],
          keyTakeaway:
            'Bu araçlar “çöp” değil, Dünya dışında yarattığımız en eski kültürel miras koleksiyonudur; bir bakıma insanlığın güneş sistemindeki ilk açık hava müzeleridir.',
        },
        {
          id: 'preservation',
          tabLabel: 'Koruma Hukuku & Artemis Geleceği',
          kicker: 'TEMA 03 · GELECEK ZİYARETLER',
          title: 'Artemis Çağında Tarihi İniş Alanları Nasıl Korunacak?',
          lead: 'Yeni nesil Ay iniş araçları ve ticari roketler yaklaştıkça, yarım asırlık Apollo ayak izlerini ve Eagle gövdesini yüksek hızlı egzoz tozundan koruma yarışı başladı.',
          paragraphs: [
            '1969’da Apollo 12, Surveyor 3’ün sadece 163 metre yanına indiğinde roket egzozunun fırlattığı ince Ay tozu, Surveyor’ın beyaz boyasını saatte yüzlerce kilometre hızla zımparalayarak bronzlaştırdı. Bugün Artemis ve ticari ay görevleri yüzeye çok daha ağır roketlerle inmeye hazırlanırken, aynı egzoz etkisinin Armstrong’un ilk ayak izlerini ve LRO kameralarıyla takip edilen izleri silmesi riski doğuyor.',
            'Bu tehlikeyi önlemek için 2020’de yürürlüğe giren “One Small Step Act” ve NASA’nın 2011 Ay Mirası Kılavuzları, Apollo iniş sahalarının çevresinde 75 metre ile 2 kilometre arasında tampon bölgeler ve uçuş yasağı koridorları tanımladı. Artemis astronotlarının gelecekte eski araçlardan malzeme örnekleri alırken tarihsel dokuya zarar vermemesi için uluslararası uzay arkeolojisi protokolleri geliştiriliyor.',
          ],
          comparisonTitle: 'Tarihi Alanlar İçin Koruma Önlemleri',
          comparisons: [
            {
              subject: '2 km Yaklaşma Tamponu',
              detail: 'Büyük iniş araçlarının roket püskürtme konilerinin eski ekipmanları kumlamasını engellemek için güvenlik sınırı.',
            },
            {
              subject: 'Sanal & LRO Belgeleme',
              detail: 'Herhangi bir insan ziyareti öncesinde tüm ayak izi ve tekerlek izlerinin santimetre ölçeğinde haritalanması.',
            },
            {
              subject: 'Geri Getirme İkilemi',
              detail: 'Surveyor 3 kamerası gibi radyasyon testi için parça almak mı, yoksa tüm anıtı yerinde korumak mı?',
            },
          ],
          keyTakeaway:
            'Bir gün Taurus-Littrow’a veya Meridiani Planum’a yeniden yürüyen insanlar, tıpkı Dünya’daki arkeolojik kazılar gibi bu makinelerin yanına saygılı bir mesafeden yaklaşacak.',
        },
      ],
    },
    catalog: {
      kicker: '04 · Kozmik Arşiv Koleksiyonu',
      title: 'Bırakılan Envanter Kataloğu',
      desc: 'Herhangi bir kalıntıyı seçerek üstteki 2D ve 3D inceleme atölyesine ve detaylı hikaye bölümüne yükleyin.',
      allTab: 'Tümü',
      moonTab: 'Ay Kalıntıları',
      marsTab: 'Mars Kalıntıları',
      allStatuses: 'Tüm Durumlar',
      emptyTitle: 'Seçili filtrelerle eşleşen kalıntı bulunamadı.',
      emptyDesc: 'Tüm Ay ve Mars envanterini görmek için filtreleri sıfırlayabilirsiniz.',
      resetFilters: 'Filtreleri Sıfırla',
      yearsSilentUnit: 'yıl sessiz',
      currentlyInspecting: 'Şu An İnceleniyor',
      openStory: 'Hikayeyi Aç',
    },
    timeline: {
      kicker: '05 · 1967 – 2026 Kronolojisi',
      title: 'Dünya Dışı Sessizliğin Zaman Çizelgesi',
      desc: 'İlk robotik Ay sondasından Mars depremlerini dinleyip toz altında uyuyan son istasyona kadar elli dokuz yıllık keşif izleri.',
      lastContact: 'Son iletişim',
      goToChapter: 'Bölüme Git',
    },
    footer: {
      subtitle:
        'Terk Edilmiş Ama Unutulmamış · NASA Ay ve Mars Görevleri Kozmik Arkeoloji Sergisi',
      top: 'Başlangıç',
      map: 'Keşif Haritası',
      studio: '2D & 3D Atölye',
      themes: 'Koruma Mirası',
      catalog: 'Arşiv Koleksiyonu',
      timeline: 'Kronoloji',
    },
    statusMap: {
      Sessiz: 'Sessiz',
      'Yansıtıcı Aktif': 'Yansıtıcı Aktif',
      'Toz Altında': 'Toz Altında',
    },
  },
  en: {
    docTitle: 'Abandoned But Not Forgotten — NASA Relics on the Moon & Mars',
    brand: 'Silent Relics',
    nav: {
      map: 'Discovery Map',
      studio: '2D & 3D Studio',
      themes: 'Heritage',
      catalog: 'Archive Catalog',
      timeline: 'Chronology',
    },
    startStory: 'Begin Story',
    switchLangLabel: 'Türkçe',
    switchLangAria: 'Switch language to Turkish',
    hero: {
      kicker: 'Cosmic Archaeology Exhibition · Moon & Mars (1967 – 2026)',
      title: 'Abandoned But Not Forgotten',
      subtitle:
        'Humanity walked on the Moon, drove across Mars, and returned home—leaving our machines behind. Explore the stories, personal keepsakes, orbital sightings, 2D engineering blueprints, and interactive 3D models of eight historic NASA relics resting across airless craters and rust-colored plains.',
      cta: 'Begin Discovery',
      stats: {
        scopeLabel: 'EXHIBITION SCOPE',
        scopeValue: '2 Worlds',
        scopeDesc: 'Lunar & Martian surfaces',
        inventoryLabel: 'ARCHIVE INVENTORY',
        inventoryValue: '8 Historic Relics',
        inventoryDesc: '2D, 3D models, artifacts & proof',
        spanLabel: 'TIME SPAN',
        spanValue: '1967 – 2022',
        spanDesc: '59 years of silent heritage',
        distanceLabel: 'DISTANCE SCALE',
        distanceValue: '384k – 225M km',
        distanceDesc: 'One-way distance from Earth',
      },
    },
    map: {
      kicker: '01 · Selenographic & Areographic Atlas',
      title: 'Coordinates of Silence',
      desc: 'Navigate the maps of the Moon and Mars; select any landing site to examine the story and surface conditions of the spacecraft left there.',
      moonTab: 'Moon (Luna) · 4 Relics',
      marsTab: 'Mars · 4 Relics',
      moonProjection: 'LUNAR NEAR SIDE · MERIDIAN PROJECTION',
      marsProjection: 'MARS LANDING ATLAS · MERCATOR PROJECTION',
      moonDistance: 'MEAN DISTANCE: 384,400 KM',
      marsDistance: 'MEAN DISTANCE: 225 MILLION KM',
      chapterPrefix: 'CHAPTER',
      yearsSilentSuffix: 'years',
      sinceText: (date, years) =>
        `Resting in place for ${years} years since ${date}.`,
      coordsLabel: 'Coordinates',
      tempLabel: 'Surface Temp',
      delayLabel: 'Signal Delay',
      statusLabel: 'Current Status',
      cta: 'Inspect 2D / 3D Model & Story',
    },
    workshop: {
      kicker: '02 · Story, Relics, 2D & 3D Inspection Studio',
      chapterOf: 'CHAPTER',
      totalChapters: '08',
      dossierTabs: {
        narrative: 'Story & Legacy',
        relics: 'Left-Behind Relics',
        science: 'Science & Orbit',
      },
      relicsHeading: 'Personal & Symbolic Artifacts Left at the Site',
      relicsIntro:
        'More than alloy frames remained on those distant plains—crews and engineers entrusted quiet emblems of human memory to the dust.',
      scienceBreakthroughsHeading: 'Defining Scientific Breakthroughs',
      orbitalVerificationHeading: 'Orbital Reconnaissance Evidence',
      crewTeamLabel: 'Crew / Engineering Team',
      finalTxTitle: 'FINAL RECORDED TRANSMISSION',
      accessionTitle: 'Accession Record & Physical Inventory',
      siteLabel: 'Landing Site',
      abandonedLabel: 'Abandoned Date',
      massLabel: 'Mass Left Behind',
      dimensionsLabel: 'Dimensions',
      statusNoteLabel: 'Condition Note',
      modelTitle: 'Interactive 3D & 2D Model Studio',
      modelDesc3d:
        'Orbit the spacecraft 360°, separate sub-assemblies with the exploded-view slider, and tap numbered markers to read each component’s story.',
      modelDesc2d:
        'Click numbered markers on the 2D blueprint; switch to Internal X-Ray or Weathering Timeline to see how decades on another world transform the hardware.',
      tab3d: '3D Interactive Model',
      tab2d: '2D Technical Blueprint',
      prevPrefix: 'Previous',
      nextPrefix: 'Next',
    },
    viewer3d: {
      presets: {
        hero: 'Overview',
        front: 'Front View',
        top: 'Top-Down',
        detail: 'Close-Up',
      },
      sceneTag: '3D STAGE',
      dragHint: 'Drag / Zoom',
      hideControls: 'Hide Controls',
      showControls: 'Show Controls',
      explodeLabel: 'Exploded View',
      dustyLabel: '2026 Dusty',
      autoOrbit: 'Auto-Orbit',
      resetAria: 'Reset 3D camera',
      resetTitle: 'Reset View',
      webglFallback:
        '3D WebGL acceleration is currently unavailable in your browser. Please switch to the 2D Technical Blueprint tab above.',
    },
    blueprint2d: {
      modeBlueprint: 'Blueprint',
      modeXray: 'Internal (X-Ray)',
      modeWeathering: 'Weathering',
      grid: 'Grid',
      zoomOutAria: 'Zoom out',
      zoomInAria: 'Zoom in',
      resetAria: 'Reset view',
      orthographicTag: 'ORTHOGRAPHIC 2D SCHEMATIC',
      xrayTag: 'INTERNAL CUTAWAY',
      weatheringTag: 'SURFACE WEATHERING',
      timeSliderLabel: 'Timeline Exposure',
      selectedYearLabel: (year, delta) => `Selected Year: ${year} (${delta} yrs later)`,
      xrayNoteLabel: 'Internal Cutaway Note:',
      ascentDeparted: 'ASCENT STAGE (DEPARTED)',
      fuelLabel: 'FUEL',
      oxidizerLabel: 'OXIDIZER',
      lrvBatteries: '2 × 36V SILVER-ZINC BATTERIES',
      takenByApollo12: 'RETRIEVED BY APOLLO 12',
      vikingInternal: 'GC-MS BIOLOGY LAB · PU-238 HEATERS',
      sojournerInternal: '80C85 CPU · LITHIUM CELLS · AEROGEL',
      oppInternal: 'RAD6000 · 8× RHU HEATERS · LI-ION',
      challengerInternal: 'EXPANDED O₂ & H₂O TANKS · LRV-3 CARGO BAY',
      insightInternal: 'CNES SEIS VACUUM SPHERE · 2× 25AH LI-ION · UHF RELAY',
    },
    photo: {
      fiducials: 'Reseau Crosses',
      enlarge: 'Enlarge',
      enlargeAria: 'Open full-screen archival photograph',
      closeAria: 'Close full-screen view',
      loadError: 'Archival image could not be loaded.',
    },
    themesSection: {
      kicker: '03 · Cosmic Archaeology & Preservation',
      title: 'The Science of What Stays Behind',
      desc: 'Airless lunar vacuum and Martian dust storms age identical spacecraft alloys in opposite ways—while returning missions now face the duty of safeguarding our earliest off-world heritage.',
      takeawayLabel: 'Curatorial Synthesis',
      items: [
        {
          id: 'weathering',
          tabLabel: 'Weathering Physics: Moon vs. Mars',
          kicker: 'THEME 01 · ENVIRONMENTAL AGING',
          title: 'Airless Thermal Shock vs. Ferric Dust Storms',
          lead: 'Machines left on the Moon never rust, yet endure a 300 °C thermal whip every fortnight; spacecraft on Mars are gradually sandblasted and buried beneath sweeping iron-oxide silt.',
          paragraphs: [
            'With no atmosphere on the Moon, there is no wind to erase a bootprint and no oxygen to corrode aluminum. Yet sunlight drives temperatures to +127 °C before plunging to -175 °C at lunar midnight. Over fifty years of extreme expansion and contraction, adhesives behind Eagle and Challenger’s golden Kapton shrouds grew brittle, while unfiltered UV radiation bleached nylon flags stark white.',
            'On Mars, a thin carbon-dioxide sky hosts continent-spanning dust storms. Viking 1, Sojourner, Opportunity, and InSight all accumulated fine micron-scale iron-oxide blankets. Even though lucky whirlwinds occasionally swept Opportunity’s wings clean for fourteen years, calm equatorial silt eventually sealed InSight’s fate.',
          ],
          comparisonTitle: 'Dual Planetary Aging Mechanisms',
          comparisons: [
            {
              subject: 'Lunar Surface (Apollo & Surveyor)',
              detail: 'Hypervelocity micrometeoroids pit bare metal at 20 km/s; astronaut footprints remain crisp for over 1 million years.',
            },
            {
              subject: 'Martian Surface (Viking, MER & InSight)',
              detail: 'Dust devils and seasonal winds erase rover tracks within decades while coating solar wings in red ochre.',
            },
            {
              subject: 'Power Longevity (RTG vs. Solar)',
              detail: 'Plutonium-238 inside Viking 1 still radiates warmth 44 years later, whereas solar-powered InSight fell silent solely from dust.',
            },
          ],
          keyTakeaway:
            'Future explorers must engineer not only soft landings, but electrodynamic dust shields capable of repelling razor-sharp lunar regolith and adhesive Martian silt.',
        },
        {
          id: 'humanity',
          tabLabel: 'Human Traces & Off-World Art',
          kicker: 'THEME 02 · SILENT KEEPSAKES',
          title: 'Human Memory Engraved Into Distant Hardware',
          lead: 'Every craft sent beyond Earth is both a laboratory and a time capsule—carrying peace medallions, tiny sculptures, family initials, and millions of ordinary names.',
          paragraphs: [
            'Apollo crews left more than seismometers on the lunar soil. Apollo 11 deposited a gold olive branch pin and a coin-sized silicon disc etched with messages from 73 nations. At Hadley Rille, Apollo 15 commander David Scott gently laid the 8.5-centimeter aluminum “Fallen Astronaut” sculpture alongside a plaque honoring 14 fallen American and Soviet flyers.',
            'Robotic explorers carried that human touch forward to Mars. Opportunity’s Rock Abrasion Tool wore an aluminum cable cuff forged from World Trade Center steel; Pathfinder carried 300,000 names, Opportunity 4 million, and InSight 2.4 million Earth citizens etched onto silicon chips beneath Martian skies.',
          ],
          comparisonTitle: 'Off-World Cultural Archive',
          comparisons: [
            {
              subject: 'Apollo 17 · “TDC” Initials (1972)',
              detail: 'Eugene Cernan traced his daughter Tracy’s initials into Taurus-Littrow dust minutes before departure.',
            },
            {
              subject: 'Opportunity · Twin Towers Steel (2004)',
              detail: 'Protective metal cuff mounted to the robotic arm’s abrasion tool to honor 9/11 victims.',
            },
            {
              subject: 'Microchip Signatures on Mars',
              detail: 'Over 6.7 million names preserved across Pathfinder, Opportunity, and InSight decks.',
            },
          ],
          keyTakeaway:
            'Far from space debris, these silent machines form humanity’s oldest extraterrestrial cultural heritage—the first open-air museums beyond our home planet.',
        },
        {
          id: 'preservation',
          tabLabel: 'Space Law & Artemis Protection',
          kicker: 'THEME 03 · FUTURE RETURN',
          title: 'Protecting Historic Landing Sites in the Artemis Era',
          lead: 'As heavy commercial and crewed landers prepare to return to the Moon, space archaeologists are racing to shield half-century-old footprints from supersonic rocket exhaust.',
          paragraphs: [
            'When Apollo 12 touched down 163 meters from Surveyor 3 in 1969, Intrepid’s exhaust plume hurled razor-sharp lunar grit at hundreds of meters per second, sandblasting Surveyor’s white paint to a weathered tan. Much larger Artemis-era landers could scour Tranquility Base from kilometers away if approach corridors go unguarded.',
            'In response, NASA’s 2011 Lunar Heritage Guidelines and the 2020 One Small Step Act establish keep-out buffers ranging from 75 meters to 2 kilometers around historic Apollo sites, preserving bootpaths and equipment while orbital probes catalog every disturbed grain from above.',
          ],
          comparisonTitle: 'Safeguarding Off-World Heritage',
          comparisons: [
            {
              subject: '2 km Exhaust Exclusion Zones',
              detail: 'Approach corridors keeping rocket blast plumes from erasing Neil Armstrong’s first footprints.',
            },
            {
              subject: 'Orbital Photogrammetry',
              detail: 'Mapping every rover track and footpad shadow at decimeter scale before human boots return.',
            },
            {
              subject: 'Salvage vs. In-Situ Preservation',
              detail: 'Balancing materials-science study—like Surveyor 3’s camera—against leaving monuments untouched.',
            },
          ],
          keyTakeaway:
            'When explorers walk again through Taurus-Littrow or Meridiani Planum, they will approach these pioneering machines much as archaeologists step onto sacred ground.',
        },
      ],
    },
    catalog: {
      kicker: '04 · Cosmic Archive Collection',
      title: 'Left-Behind Inventory Catalog',
      desc: 'Select any artifact to load its story, keepsakes, archival imagery, and 2D / 3D inspection models in the studio above.',
      allTab: 'All',
      moonTab: 'Lunar Relics',
      marsTab: 'Martian Relics',
      allStatuses: 'All Statuses',
      emptyTitle: 'No artifacts match the selected filters.',
      emptyDesc: 'Reset filters to browse the complete Moon and Mars archive.',
      resetFilters: 'Reset Filters',
      yearsSilentUnit: 'yrs silent',
      currentlyInspecting: 'Inspecting Now',
      openStory: 'Open Story',
    },
    timeline: {
      kicker: '05 · 1967 – 2026 Chronology',
      title: 'Timeline of Off-World Silence',
      desc: 'Fifty-nine years of quiet footsteps—from the first robotic lunar scout to the seismic lander slumbering beneath Elysium Planitia’s red dust.',
      lastContact: 'Last contact',
      goToChapter: 'Go to Chapter',
    },
    footer: {
      subtitle:
        'Abandoned But Not Forgotten · Cosmic Archaeology Exhibition of NASA Moon & Mars Missions',
      top: 'Top',
      map: 'Discovery Map',
      studio: '2D & 3D Studio',
      themes: 'Heritage',
      catalog: 'Archive Catalog',
      timeline: 'Chronology',
    },
    statusMap: {
      Sessiz: 'Silent',
      'Yansıtıcı Aktif': 'Reflector Active',
      'Toz Altında': 'Under Dust',
    },
  },
};
